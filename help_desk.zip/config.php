<?php

$dbservername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="help_desk";

?>